/**
 * Data models
 */
Apperyio.Entity = new Apperyio.EntityFactory({
    "Number": {
        "type": "number"
    },
    "Boolean": {
        "type": "boolean"
    },
    "groceryList": {
        "type": "array",
        "items": {
            "type": "groceryObject"
        }
    },
    "groceryObject": {
        "type": "object",
        "properties": {
            "Name": {
                "type": "string"
            },
            "Amount": {
                "type": "string"
            }
        }
    },
    "String": {
        "type": "string"
    },
    "cartList": {
        "type": "array",
        "items": {
            "type": "groceryObject"
        }
    }
});
Apperyio.getModel = Apperyio.Entity.get.bind(Apperyio.Entity);

/**
 * Data storage
 */
Apperyio.storage = {

    "itemName": new $a.SessionStorage("itemName", "String"),

    "numOfItem": new $a.SessionStorage("numOfItem", "Number"),

    "idOfItem": new $a.SessionStorage("idOfItem", "String"),

    "groceryList": new $a.LocalStorage("groceryList", "groceryList"),

    "groceryObject": new $a.SessionStorage("groceryObject", "groceryObject"),

    "cartList": new $a.SessionStorage("cartList", "cartList")
};